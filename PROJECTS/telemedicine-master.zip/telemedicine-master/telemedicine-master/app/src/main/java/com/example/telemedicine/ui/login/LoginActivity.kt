package com.example.telemedicine.ui.login


/*** Kuncappu Kumar ***/

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.telemedicine.AppConstants
import com.example.telemedicine.R
import com.example.telemedicine.databinding.ActivityLoginBinding
import com.example.telemedicine.ui.onboarding.UserChoice
import com.example.telemedicine.ui.userspace.doctor.DoctorSpace
import com.example.telemedicine.ui.userspace.patient.PatientSpace
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class LoginActivity : AppCompatActivity() {

    private lateinit var bind : ActivityLoginBinding
    private lateinit var firebaseAuth: FirebaseAuth
    var email:String=""
    var password:String=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        bind= ActivityLoginBinding.inflate(layoutInflater)
        setContentView(bind.root)


        firebaseAuth = FirebaseAuth.getInstance()
        bind.loginLayout.btnRegister.setOnClickListener{
            bind.progressBar6.visibility = View.VISIBLE
            email=bind.loginLayout.etEmail.text.toString()
            password=bind.loginLayout.etPassword.text.toString()
            if(email.isNotEmpty() && password.isNotEmpty()) {
                firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener {
                    if (it.isSuccessful) {
                        var userid = firebaseAuth.currentUser!!.uid
                        Log.d("userid",userid)
                        save_to_shared_prefs()
                        runBlocking {
                            val job = additional_task(userid)
                            job.join()
                        }
                    } else {
                        bind.progressBar6.visibility = View.GONE
                        create_snackbar( "Login failed incorrect email and password retry")
                    }
                }
            }else {
                bind.progressBar6.visibility = View.GONE
                create_snackbar("Empty Fields")
            }
        }

        bind.loginLayout.passwordVisible.setOnClickListener{
            if (bind.loginLayout.etPassword.transformationMethod != null) {
                bind.loginLayout.passwordVisible.
                setImageResource(R.drawable.ic_baseline_visibility_24)
                bind.loginLayout.etPassword.setTransformationMethod(null)
            }else {
                bind.loginLayout.passwordVisible.
                setImageResource(R.drawable.ic_baseline_visibility_off_24)
                bind.loginLayout.etPassword.setTransformationMethod(
                    PasswordTransformationMethod()
                )
            }
        }

    }

    private fun additional_task(userid: String) = GlobalScope.launch {
            //// User collection querying to know the user_type based on the userid
            FirebaseDatabase.getInstance().getReference(AppConstants.usr_coll_name).child(userid!!).
            get().addOnCompleteListener {
                if (it.isSuccessful){
                    var user_info =  it.result.value as HashMap<String,String>
                    when(user_info.get("user_type")){
                        "P"->{
                           check_if_info_filled(userid,AppConstants.patient_coll_name)
                        }

                        "D"->{
                            check_if_info_filled(userid,AppConstants.doctor_coll_name)
                        }
                    }
                }
            }
        }

    private fun check_if_info_filled(userid: String, CollName: String): Boolean {
        var op = false
        runBlocking {
            val job = GlobalScope.launch {
                FirebaseDatabase.getInstance().getReference(CollName).child(userid).get().addOnCompleteListener {
                    if (it.isSuccessful){
                        var user_info =  it.result.value
                        if (user_info != null){
                            navigate_to_user_space(CollName)
                        }else {
                            fill_remaining_info()
                        }
                    }
                }
            }

            job.join()
        }
        return op
    }

    private fun fill_remaining_info() {
        bind.progressBar6.visibility = View.GONE
        Toast.makeText(this@LoginActivity, "Login Success", Toast.LENGTH_SHORT).show()
        var intent = Intent(this@LoginActivity,
                    UserChoice::class.java)
        startActivity(intent)
        finish()
    }

    private fun navigate_to_user_space(CollName: String) {
        when(CollName){
            AppConstants.patient_coll_name -> {
                save_to_shared_prefs_patient()
                bind.progressBar6.visibility = View.GONE
                Toast.makeText(this@LoginActivity, "Login Success", Toast.LENGTH_SHORT).show()
                var intent = Intent(this@LoginActivity,
                    PatientSpace::class.java)
                startActivity(intent)
                finish()
            }

            AppConstants.doctor_coll_name ->{
                save_to_shared_prefs_doc()
                bind.progressBar6.visibility = View.GONE
                Toast.makeText(this@LoginActivity, "Login Success", Toast.LENGTH_SHORT).show()
                var intent = Intent(this@LoginActivity,
                    DoctorSpace::class.java)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun save_to_shared_prefs() {
        val sharedPreference =  getSharedPreferences(AppConstants.sharedPrefName, Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        editor.putString(AppConstants.userid,FirebaseAuth.getInstance().currentUser!!.uid.toString())
        editor.commit()
    }

    private fun save_to_shared_prefs_doc(){
        val sharedPreference =  getSharedPreferences(AppConstants.sharedPrefName, Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        editor.putBoolean(AppConstants.doctor_info_filled,true)
        editor.commit()
    }

    private fun save_to_shared_prefs_patient(){
        val sharedPreference =  getSharedPreferences(AppConstants.sharedPrefName, Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        editor.putBoolean(AppConstants.patient_info_filled,true)
        editor.commit()
    }

    private fun create_snackbar(text:String) {
        val snackbar = Snackbar.make(bind.root, text,
            Snackbar.LENGTH_LONG)
        snackbar.show()
    }


}