package com.example.telemedicine.model

data class DoctorConsulationReq (val patient_name : String,val time_slot:String, val date_slot:String)