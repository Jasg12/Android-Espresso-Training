package com.example.telemedicine.model

data class PatientConsulationReq (val doctor_name:String,val time_slot:String, val date_slot:String)