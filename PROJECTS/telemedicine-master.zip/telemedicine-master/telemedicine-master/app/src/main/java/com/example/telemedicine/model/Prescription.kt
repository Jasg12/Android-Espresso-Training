package com.example.telemedicine.model

data class Prescription(var doctor_name:String, val date:String, val imageUrl:String)
