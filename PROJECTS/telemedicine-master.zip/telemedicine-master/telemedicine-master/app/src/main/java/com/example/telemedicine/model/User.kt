package com.example.telemedicine.model

data class User(val email:String,val user_type:String)
