package com.example.telemedicine.ui.model

data class Patient(var name:String?=null, var age :String? = null, var phone :String?= null,var blood_group:String?=null,var  gender:String? = null, var med_history:String? = null)