package com.example.espresso_signupform

import android.app.Activity
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.os.Bundle
import android.view.View
import android.view.View.OnFocusChangeListener
import android.widget.EditText
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : Activity() {
    private var calendarEditText: EditText? = null
    private val calendar: Calendar? = Calendar.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        calendarEditText = findViewById(R.id.editText_birthday)
        val datePicker =
            OnDateSetListener { datePicker, year, month, day ->
                with(calendar)

                    this?.set(Calendar.YEAR, year)
                    this?.set(Calendar.MONTH, month)
                    this?.set(Calendar.DAY_OF_MONTH, day)
                }
                updateLabel()
            }
        calendarEditText?.setOnFocusChangeListener(OnFocusChangeListener { view, hasFocus ->
            if (hasFocus) {
                calendar?.let {
                    DatePickerDialog(
                        this@MainActivity, datePicker, it.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
                    )
                        .show()
                }
            }
        })
    }

    private fun updateLabel() {
        val dateFormat = "MM/dd/yy"
        val sdf = SimpleDateFormat(dateFormat, Locale.US)
        calendarEditText!!.setText(sdf.format(calendar!!.time))
    }

    fun register(view: View?) {
        val nameEditText = findViewById<EditText>(R.id.editText_name)
        val name = nameEditText.text.toString().trim { it <= ' ' }
        val lastnameEditText = findViewById<EditText>(R.id.editText_lastname)
        val lastname = lastnameEditText.text.toString().trim { it <= ' ' }
        val greeting = getString(R.string.greeting) + ": " + name + " " + lastname
        Toast.makeText(this, greeting, Toast.LENGTH_LONG).show()
    }
}