package com.example.espresso_signupform

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import android.support.

import androidx.test.runner.AndroidJUnit4
import androidx.test.espresso.Espresso
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.matcher.RootMatchers
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.filters.LargeTest
import com.example.espresso_signupform.MainActivity
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.not
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@LargeTest
class MainActivityEspressoTest {
    @Rule
    var mainActivityRule: <MainActivity> =
        ActivityScenarioRule(MainActivity::class.java)

    @Test
    @Throws(Exception::class)
    fun displaysTitle() {
        val title = "Registration form"
        Espresso.onView(withText(title)).check(matches(ViewMatchers.isDisplayed()))
    }

    @Test
    @Throws(Exception::class)
    fun greetsUser() {
        Espresso.onView(withId(R.id.editText_name)).perform(ViewActions.typeText("Sebastian"))
        Espresso.onView(withId(R.id.editText_lastname)).perform(ViewActions.typeText("Puente"))
        Espresso.onView(withId(R.id.editText_email))
            .perform(ViewActions.typeText("sebas@sample.com"))
        Espresso.onView(withId(R.id.textView_title)).perform(click())
        Espresso.closeSoftKeyboard()
        Espresso.onView(withId(R.id.button_registrar)).perform(click())

        //Toast message displayed
        Espresso.onView(withText("Hello: Sebastian Puente")).inRoot(
            RootMatchers.withDecorView(
                not(
                    `is`(
                        mainActivityRule.getActivity().getWindow().getDecorView()
                    )
                )
            )
        ).check(matches(ViewMatchers.isDisplayed()))
    }
}